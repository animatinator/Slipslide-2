#!/usr/bin/env python

## Animation loader - part of the Penuine game engine
# Loads individual animation frames from filmstrip image files, and returns a list
# Copyright ExeSoft 2007
#
# Update history:
# Created - Monday 17th December 2007, by David Barker
# Version 1.0 finished - *


import pygame
