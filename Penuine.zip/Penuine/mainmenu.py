#!/usr/bin/env python

## Main menu - part of the Penuine game engine
# Creates a main menu and sends data back to the main file
# Copyright ExeSoft 2007
#
# Update history:
# Created - Monday 17th December 2007, by David Barker
# Version 1.0 finished - *
