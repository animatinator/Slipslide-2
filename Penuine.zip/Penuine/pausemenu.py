#!/usr/bin/env python

## Pause Menu - part of the Penuine game engine
# Creates a pause menu, sending signals back to the level controller
# Copyright ExeSoft 2007
#
# Update history:
# Created - Monday 17th December 2007, by David Barker
# Version 1.0 finished - *

import pygame


class PauseMenu():
    def __init__(self):
        """
    The initialisation method, which takes no variables.
        """
        self.image = pygame.image.load("Data\\pause\\background.png").convert_alpha()
        self.mainrect = self.image.get_rect()
        self.mainrect.x = 150
        self.mainrect.y = 120
        self.paused = True
        self.screen = pygame.display.get_surface()
        
    def ShowMenu(self):
        pass
        while self.paused == True:
            self.screen.blit(self.image, self.mainrect)
            pygame.display.update(self.mainrect)
