#!/usr/bin/env python

## Level Intros - part of the Penuine game engine
# Functionality not certain
# Copyright ExeSoft 2007
#
# Update history:
# Created - Monday 17th December 2007, by David Barker
# Version 1.0 finished - *
